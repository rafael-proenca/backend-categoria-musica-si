package com.utfpr.backendcategoriamusicasi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCategoriaMusicaSiApplicationTests {

	@Test
	void contextLoads() {
	}

}
